#!/bin/bash
if [ `ps aux|grep phpADSV3|grep "master process"|grep -v "grep" | wc -l` != 1 ]; then
	echo 0
else
	echo 1
fi		

