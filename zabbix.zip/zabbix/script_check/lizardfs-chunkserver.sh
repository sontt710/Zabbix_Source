#!/bin/bash
if [ `service lizardfs-chunkserver status | /bin/grep "running" | /usr/bin/wc -l` != 1 ]; then
	echo 0
else
	echo 1
fi		

