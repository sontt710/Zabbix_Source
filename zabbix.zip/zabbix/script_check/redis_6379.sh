#!/bin/bash
if [ `service redis_6379 status | /bin/grep "running" | /usr/bin/wc -l` != 1 ]; then
	echo 0
else
	echo 1
fi		

