#!/bin/bash
if [ `service lizardfs-metalogger status | /bin/grep "running" | /usr/bin/wc -l` != 1 ]; then
	echo 0
else
	echo 1
fi		

